# Akb4r-BOT

<p align="center">
  <a href="https://github.com/SlavyanDesu"><img src="https://avatars3.githubusercontent.com/u/28254882?s=400&u=25765902db0b709938966cf4127ac11af5eafb5d&v=4" height="128" width="128" /></a>

### 𝗧𝗵𝗮𝗻𝗸𝘀 𝗙𝗼𝗿 𝗠𝗵𝗮𝗻𝗸𝗕𝗮𝗿𝗕𝗮𝗿

### WARNING
MAU RE-UPLOAD SCRIPT? KASIH NAMA/LINK CHANEL SAYA.... DILARANG UBAH INFO!!!

## NOTE:> 
SCRIPTNYA JANGAN DI JUAL/BELI KAN.. SCRIPT INI 100% GRATIS BUAT KALIAN PENGGUNA TERMUX
</div>

### ALAT DAN BAHAN <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Hello_Big.gif" width="29px">
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan kode qr kak)
> jaringan internet kenceng,kuota+
> penyimpanan yang memadai
> aplikasi whatsapp
> aplikasi termux
> kopi+rokok ;v
```

### CARA INSTALLNYA  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/hmm.gif" width="29px">
Script ini di modifikasi sama saya sendiri BARXNL-BOT.
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> git clone https://github.com/BarBot-spec/Akb4r-BOT
> cd Akb4r-BOT
> bash install.sh
> node index js
> Tinggal scan kode qr yeee...done
```

## FEATURES  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Earth.gif" width="29px">

| BARXNL-BOT    |                   Feature        |
| :-----------: | :------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Nulis                            |
|       ✅       | add                          |
|       ✅       | kick                     |
|       ✅       | demote                     |
|       ✅       | promote                       |
|       ✅       | bc           |
|       ✅       | welcome                           |
|       ✅       | Youtube Downloader               |
|       ✅       | simi                           |
|       ✅       | left                    |
|       ✅       | setpp                    |
|       ✅       | group buka/tutup                   |
|       ✅       | nsfwloli                 |
|       ✅       | loli              |
|       ✅       | tts                            |
|       ✅       | tiktokstalk          |
|       ✅       | tiktok             |
|       ✅       | tagall               |
|       ✅       | clearall             |
|       ✅       | block        |
|       ✅       | unblock                        |
|       ✅       | sound                              |
|       ✅       | tsticker                    |
|       ✅       | nulis                             |
|       ✅       | meme                           |
|       ✅       | memeindo                     |
|       ✅       | ocr                      |
|       ✅       | clone                            |
|       ✅       | bc                          |
|       ✅       | leave                             |
|       ✅       | url2img                           |
|       ✅       | wait                          |
|            info/donate/creator                  |

Ket: Aktiv 24 jam
