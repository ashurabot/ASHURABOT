const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do ashura:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  TRADUZIDO POR *ICARO*
  DUVIDAS? 👇
  WA.me/5527992752045
╚════════════════════`
}

exports.ashuramenu = 𝘼𝙎𝙃𝙐𝙍𝘼










